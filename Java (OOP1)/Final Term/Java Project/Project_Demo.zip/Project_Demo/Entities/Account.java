package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class Account
{
	private String name;
	private String pass;
	private String email;
	File myfile;
	FileWriter fwrite;
	Scanner sc;
	
	public Account()
	{
		
	}
	
	public Account(String name,String pass)
	{
		this.name=name;
		this.pass=pass;
	}
	
	public Account(String name, String pass, String email)
	{
		this.name = name;
		this.pass = pass;
		this.email = email;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public void setPass(String pass)
	{
		this.pass=pass;
	}
	
	public void setEmail(String email)
	{
		this.email = email;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getPass()
	{
		return pass;
	}
	
	public String getEmail()
	{
		return email;
	}
	
	private File getDataFile()
	{
		File dir = new File(System.getProperty("user.dir"), "Data_all");
		if(!dir.exists())
		{
			dir.mkdirs();
		}
		return new File(dir, "Data.txt");
	}
	
	public boolean addAccount()
	{
		try
		{
			myfile = getDataFile();
			if(!myfile.exists())
			{
				myfile.createNewFile();
			}
			
			try (FileWriter fwrite = new FileWriter(myfile, true);
				BufferedWriter bw = new BufferedWriter(fwrite))
			{
				bw.write(getName() + "\t" + getEmail() + "\t" + getPass() + "\n");
			}
			return true;
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
			return false;
		}
	}
	
	public boolean getAccount(String uname,String upass)
	{
		boolean flag=false;
		try
		{
			myfile = getDataFile();
			
			sc=new Scanner(myfile);
			
			while(sc.hasNextLine())
			{
				String line=sc.nextLine();
				String value[]=line.split("\t");
				if(value.length >= 3 && value[0].equals(uname) && value[2].equals(upass))
				{
					flag=true;
				}
			}
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		return flag;
	}
	
	
	
}