package Entities;

import java.lang.*;
import java.util.*;
import java.io.*;
import Frames.*;

public class Account
{
	private String name;
	private String pass;
	File myfile;
	FileWriter fwrite;
	Scanner sc;
	
	public Account()
	{
		
	}
	
	public Account(String name,String pass)
	{
		this.name=name;
		this.pass=pass;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public void setPass(String pass)
	{
		this.pass=pass;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getPass()
	{
		return pass;
	}
	
	public void addAccount()
	{
		try
		{
			myfile=new File("./Datas/Data.txt");
			myfile.createNewFile();
			
			fwrite=new FileWriter(myfile,true);
			
			fwrite.write(getName()+"\t");
			fwrite.write(getPass()+"\n");
			
			fwrite.flush();
			fwrite.close();
			
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public boolean getAccount(String uname,String upass)
	{
		boolean flag=false;
		try
		{
			myfile=new File("./Datas/Data.txt");
			
			sc=new Scanner(myfile);
			
			while(sc.hasNextLine())
			{
				String line=sc.nextLine();
				String value[]=line.split("\t");
				if(value[0].equals(uname)&&value[1].equals(upass))
				{
					flag=true;
				}
			}
			
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		return flag;
	}
	
	
	
}